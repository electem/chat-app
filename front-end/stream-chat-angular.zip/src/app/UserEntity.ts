export class UserEntity {
  id: number;
  name: string;
  age: string;
  gender: string;
  image: string;
  created_at: Date;
  updated_at: Date;
}
