-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.5.27 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for adonisdatabase
CREATE DATABASE IF NOT EXISTS `adonisdatabase` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `adonisdatabase`;

-- Dumping structure for table adonisdatabase.adonis_schema
CREATE TABLE IF NOT EXISTS `adonis_schema` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `batch` int(11) DEFAULT NULL,
  `migration_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table adonisdatabase.adonis_schema: ~2 rows (approximately)
/*!40000 ALTER TABLE `adonis_schema` DISABLE KEYS */;
INSERT INTO `adonis_schema` (`id`, `name`, `batch`, `migration_time`) VALUES
	(1, '1609834025753_users_schema', 1, '2021-01-06 15:52:14'),
	(2, '1609834853442_messages_schema', 1, '2021-01-06 15:52:14');
/*!40000 ALTER TABLE `adonis_schema` ENABLE KEYS */;

-- Dumping structure for table adonisdatabase.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `message` varchar(254) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_foreign` (`user_id`),
  CONSTRAINT `messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table adonisdatabase.messages: ~10 rows (approximately)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` (`id`, `user_id`, `message`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 1, 'Hi', '2021-01-06 16:08:47', '2021-01-06 16:08:47', '2021-01-06'),
	(2, 2, 'Hi how are you', '2020-11-05 16:11:37', '2020-12-06 16:11:38', '2021-01-06'),
	(3, 1, 'Hello ', '2021-01-06 16:11:53', '2021-01-05 16:11:54', '2021-01-06'),
	(4, 1, 'Deployment is done', '2021-01-04 19:19:37', '2021-01-06 19:19:37', '2021-01-06'),
	(5, 1, 'Fixed this issue', '2021-01-03 19:20:02', '2021-01-06 19:20:02', '2021-01-06'),
	(6, 3, 'shall we go for lunch', '2021-01-06 20:13:13', '2021-01-06 20:13:13', NULL),
	(7, 3, 'i am offline now', '2021-01-06 20:13:13', '2021-01-06 20:13:13', NULL),
	(8, 2, 'hye bro', '2021-01-06 16:11:53', '2021-01-05 16:11:54', '2021-01-06'),
	(9, 4, 'boss is asking about you.', '2021-01-04 19:19:37', '2021-01-06 19:19:37', '2021-01-06'),
	(10, 5, 'hye..', '2021-01-03 19:20:02', '2021-01-06 19:20:02', '2021-01-06');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Dumping structure for table adonisdatabase.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `gender` varchar(254) DEFAULT NULL,
  `image` varchar(254) DEFAULT NULL,
  `password` varchar(60) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table adonisdatabase.users: ~5 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `gender`, `image`, `password`, `created_at`, `updated_at`) VALUES
	(1, 'API_USER', 'male', 'https://tpc.googlesyndication.com/simgad/18016187071986703145?sqp=4sqPyQQrQikqJwhfEAEdAAC0QiABKAEwCTgDQPCTCUgAUAFYAWBfcAJ4AcUBLbKdPg&rs=AOga4ql5e4DBQY0a8xs3Z-Aj7Bzbji8dpw', '$2a$10$Lx./ag1Zi8bBc5ZBQ2JGhe4U..CAwHlBIQYBX6HMLS8a0lQ5fRMT6', '2021-01-06 15:53:07', '2021-01-06 15:53:07'),
	(2, 'Santosh', 'male', 'https://tpc.googlesyndication.com/simgad', '$2a$10$Lx./ag1Zi8bBc5ZBQ2JGhe4U..CAwHlBIQYBX6HMLS8a0lQ5fRMT6', '2021-01-06 16:05:55', '2021-01-06 16:05:55'),
	(3, 'Swagat', 'male', NULL, '$2a$10$Lx./ag1Zi8bBc5ZBQ2JGhe4U..CAwHlBIQYBX6HMLS8a0lQ5fRMT6', '2021-01-06 16:09:08', '2021-01-06 16:09:09'),
	(4, 'Diana', 'Female', NULL, '$2a$10$Lx./ag1Zi8bBc5ZBQ2JGhe4U..CAwHlBIQYBX6HMLS8a0lQ5fRMT6', '2021-01-06 19:24:42', '2021-01-06 19:24:42'),
	(5, 'Divya', 'Female', 'https://tpc.googlesyndication.com/simgad', '$2a$10$Lx./ag1Zi8bBc5ZBQ2JGhe4U..CAwHlBIQYBX6HMLS8a0lQ5fRMT6', '2021-01-06 19:38:24', '2021-01-06 19:38:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
